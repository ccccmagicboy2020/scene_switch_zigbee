#ifndef __FLASH_H__
#define __FLASH_H__

#define Address_Data       0x2f00
#define Address_Backups    0x3f00
#define Length_Data        20
#define Read               1
#define Write              0

void Flash_EraseBlock(unsigned int fui_Address);//��������
void FLASH_WriteData(unsigned char fui_Address, unsigned int fuc_SaveData);//д��һ������
void Flash_WriteArr(unsigned int fui_Address,unsigned char fuc_Length,unsigned char *fucp_SaveArr);//д�����ⳤ������
void Flash_ReadArr(unsigned int fui_Address,unsigned char fuc_Length,unsigned char *fucp_SaveArr);//��ȡ���ⳤ������
void Flash_Process(unsigned int fui_Address,unsigned int back_Address,unsigned char fuc_Length,unsigned char *fucp_SaveArr,bit WR_Flag);
void Flash_RST_ReadArr(unsigned int fui_Address,unsigned int back_Address,unsigned char fuc_Length,unsigned char *fucp_SaveArr);
unsigned int CRC_CalcCRC_Process(unsigned char *fucp_CheckArr,unsigned int fui_CheckLen,unsigned char *CRC_Data,bit CRC_Flag);



#endif